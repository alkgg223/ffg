package com.example.gunsmod;

import java.util.List;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.item.ItemStack;

public class GunWorkbenchScreen extends AbstractContainerScreen<GunWorkbenchMenu> {
    private int selected = 0;

    public GunWorkbenchScreen(GunWorkbenchMenu menu, Inventory inv, Component title) {
        super(menu, inv, title);
        this.imageWidth = 276;
        this.imageHeight = 200;
    }

    @Override
    protected void renderLabels(GuiGraphics g, int mx, int my) {
    }

    private int cellX(int i) {
        return leftPos + 10 + (i % 4) * 30;
    }

    private int cellY(int i) {
        return topPos + 32 + (i / 4) * 30;
    }

    private int btnX() {
        return leftPos + 142;
    }

    private int btnY() {
        return topPos + 172;
    }

    private boolean canCraft() {
        WorkbenchRecipes.Entry e = WorkbenchRecipes.all().get(selected);
        return minecraft != null && minecraft.player != null && WorkbenchRecipes.canAfford(minecraft.player, e.costs());
    }

    @Override
    protected void renderBg(GuiGraphics g, float pt, int mx, int my) {
        int x = leftPos, y = topPos;
        g.fill(x - 2, y - 2, x + imageWidth + 2, y + imageHeight + 2, 0xFF000000);
        g.fill(x, y, x + imageWidth, y + imageHeight, 0xFF2B2F36);
        g.fill(x, y, x + imageWidth, y + 22, 0xFF181B20);
        g.fill(x, y + 22, x + imageWidth, y + 24, 0xFFE0A030);
        g.drawString(font, "GUN WORKBENCH", x + 10, y + 8, 0xFFE0A030, false);

        List<WorkbenchRecipes.Entry> list = WorkbenchRecipes.all();
        for (int i = 0; i < list.size(); i++) {
            int cx = cellX(i), cy = cellY(i);
            boolean sel = i == selected;
            boolean hov = mx >= cx && mx < cx + 28 && my >= cy && my < cy + 28;
            g.fill(cx, cy, cx + 28, cy + 28, sel ? 0xFFE0A030 : 0xFF000000);
            g.fill(cx + 1, cy + 1, cx + 27, cy + 27, hov ? 0xFF4C5460 : 0xFF3A404A);
            g.renderItem(new ItemStack(list.get(i).result().get()), cx + 6, cy + 6);
        }
        g.drawString(font, "Pick a weapon, then CRAFT", x + 10, y + 128, 0xFF8A919C, false);

        int px = x + 138;
        g.fill(px, y + 28, x + imageWidth - 6, y + imageHeight - 6, 0xFF1F2227);

        WorkbenchRecipes.Entry e = list.get(selected);
        ItemStack out = new ItemStack(e.result().get(), e.count());
        g.renderItem(out, px + 6, y + 33);
        g.drawString(font, out.getHoverName(), px + 28, y + 38, 0xFFFFFFFF, false);

        int ty = y + 56;
        if (e.gun() != null) {
            GunType t = e.gun();
            String dmg = t.pellets > 1 ? t.damage + " x" + t.pellets : String.valueOf(t.damage);
            String[] lines = {
                    "Damage: " + dmg + (t.explosive > 0 ? " + blast" : ""),
                    "Magazine: " + t.magSize,
                    "Fire rate: " + String.format("%.1f", 20f / t.fireDelay) + "/s" + (t.automatic ? " (auto)" : ""),
                    "Range: " + (int) t.range + " blocks",
                    "Reload: " + String.format("%.1f", t.reloadTicks / 20f) + "s",
                    "Recoil: " + t.recoil
            };
            for (String s : lines) {
                g.drawString(font, s, px + 6, ty, 0xFFB8C0CC, false);
                ty += 10;
            }
        } else {
            g.drawString(font, "Ammo for all guns", px + 6, ty, 0xFFB8C0CC, false);
            g.drawString(font, "x" + e.count() + " bullets", px + 6, ty + 10, 0xFFB8C0CC, false);
        }

        g.drawString(font, "Cost:", px + 6, y + 120, 0xFFE0A030, false);
        boolean creative = minecraft != null && minecraft.player != null && minecraft.player.getAbilities().instabuild;
        for (int i = 0; i < e.costs().size(); i++) {
            WorkbenchRecipes.Cost c = e.costs().get(i);
            int cx = px + 6 + (i % 2) * 62;
            int cy = y + 132 + (i / 2) * 18;
            ItemStack icon = new ItemStack(c.item().get());
            g.renderItem(icon, cx, cy);
            int have = minecraft != null && minecraft.player != null ? WorkbenchRecipes.count(minecraft.player, c.item().get()) : 0;
            boolean ok = creative || have >= c.count();
            g.drawString(font, have + "/" + c.count(), cx + 19, cy + 4, ok ? 0xFF55FF55 : 0xFFFF5555, false);
        }

        boolean can = canCraft();
        int bx = btnX(), by = btnY();
        boolean hov = mx >= bx && mx < bx + 122 && my >= by && my < by + 20;
        g.fill(bx, by, bx + 122, by + 20, can ? (hov ? 0xFF3FA84A : 0xFF2E8B3A) : 0xFF555A62);
        String label = can ? "CRAFT" : "MISSING ITEMS";
        g.drawString(font, label, bx + (122 - font.width(label)) / 2, by + 6, 0xFFFFFFFF, false);
    }

    @Override
    public void render(GuiGraphics g, int mx, int my, float pt) {
        super.render(g, mx, my, pt);
        List<WorkbenchRecipes.Entry> list = WorkbenchRecipes.all();
        for (int i = 0; i < list.size(); i++) {
            int cx = cellX(i), cy = cellY(i);
            if (mx >= cx && mx < cx + 28 && my >= cy && my < cy + 28) {
                g.renderTooltip(font, new ItemStack(list.get(i).result().get()), mx, my);
            }
        }
    }

    @Override
    public boolean mouseClicked(double mx, double my, int button) {
        List<WorkbenchRecipes.Entry> list = WorkbenchRecipes.all();
        for (int i = 0; i < list.size(); i++) {
            int cx = cellX(i), cy = cellY(i);
            if (mx >= cx && mx < cx + 28 && my >= cy && my < cy + 28) {
                selected = i;
                return true;
            }
        }
        int bx = btnX(), by = btnY();
        if (mx >= bx && mx < bx + 122 && my >= by && my < by + 20) {
            if (canCraft() && minecraft != null && minecraft.gameMode != null) {
                minecraft.gameMode.handleInventoryButtonClick(menu.containerId, selected);
            }
            return true;
        }
        return super.mouseClicked(mx, my, button);
    }
}
