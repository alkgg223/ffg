package com.example.gunsmod;

import java.util.List;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.inventory.ContainerLevelAccess;
import net.minecraft.world.item.ItemStack;

public class GunWorkbenchMenu extends AbstractContainerMenu {
    private final ContainerLevelAccess access;

    public GunWorkbenchMenu(int id, Inventory inv, ContainerLevelAccess access) {
        super(GunsMod.WORKBENCH_MENU.get(), id);
        this.access = access;
    }

    @Override
    public ItemStack quickMoveStack(Player player, int index) {
        return ItemStack.EMPTY;
    }

    @Override
    public boolean stillValid(Player player) {
        return stillValid(access, player, GunsMod.WORKBENCH.get());
    }

    /** Button id = index of the recipe in WorkbenchRecipes.all(). */
    @Override
    public boolean clickMenuButton(Player player, int id) {
        List<WorkbenchRecipes.Entry> list = WorkbenchRecipes.all();
        if (id < 0 || id >= list.size()) return false;
        WorkbenchRecipes.Entry e = list.get(id);
        if (!WorkbenchRecipes.canAfford(player, e.costs())) return false;
        if (!player.getAbilities().instabuild) {
            for (WorkbenchRecipes.Cost c : e.costs()) {
                WorkbenchRecipes.consume(player, c.item().get(), c.count());
            }
        }
        ItemStack out = new ItemStack(e.result().get(), e.count());
        player.getInventory().add(out);
        if (!out.isEmpty()) player.drop(out, false);
        player.level().playSound(null, player.getX(), player.getY(), player.getZ(),
                SoundEvents.ANVIL_USE, SoundSource.BLOCKS, 0.6f, 1.4f);
        return true;
    }
}
