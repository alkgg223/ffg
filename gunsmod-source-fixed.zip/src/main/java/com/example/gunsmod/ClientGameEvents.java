package com.example.gunsmod;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.util.Mth;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.item.ItemStack;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.ClientTickEvent;
import net.neoforged.neoforge.client.event.ComputeFovModifierEvent;
import net.neoforged.neoforge.client.event.RenderGuiEvent;
import net.neoforged.neoforge.client.event.RenderGuiLayerEvent;
import net.neoforged.neoforge.client.event.RenderHandEvent;
import net.neoforged.neoforge.client.gui.VanillaGuiLayers;
import net.neoforged.neoforge.network.PacketDistributor;

@EventBusSubscriber(modid = GunsMod.MODID, value = Dist.CLIENT)
public class ClientGameEvents {
    public static boolean aiming = false;

    private static float aimProg, aimProgO;
    private static float sprintProg, sprintProgO;
    private static float recoilAnim, recoilAnimO;
    private static GunItem lastGun = null;
    private static int lastSlot = -1;
    private static int lastAmmo = -1;

    private static boolean scopeOverlay(ItemStack st, GunItem g) {
        return g.type.scoped || GunItem.getScope(st) == 2;
    }

    @SubscribeEvent
    public static void onTick(ClientTickEvent.Post e) {
        LocalPlayer p = Minecraft.getInstance().player;
        if (p == null) return;
        boolean holding = p.getMainHandItem().getItem() instanceof GunItem;
        while (ClientModEvents.RELOAD.consumeClick()) {
            if (holding) PacketDistributor.sendToServer(new ReloadPayload());
        }
        while (ClientModEvents.AIM.consumeClick()) {
            if (holding) {
                aiming = !aiming;
                PacketDistributor.sendToServer(new AimPayload(aiming));
            }
        }
        if (!holding && aiming) {
            aiming = false;
            PacketDistributor.sendToServer(new AimPayload(false));
        }

        aimProgO = aimProg;
        aimProg += ((aiming ? 1f : 0f) - aimProg) * 0.35f;
        boolean sprint = holding && p.isSprinting() && !aiming;
        sprintProgO = sprintProg;
        sprintProg += ((sprint ? 1f : 0f) - sprintProg) * 0.3f;
        recoilAnimO = recoilAnim;
        recoilAnim *= 0.6f;

        // Detect a shot (ammo went down) -> recoil animation + camera kick
        if (holding) {
            ItemStack st = p.getMainHandItem();
            GunItem g = (GunItem) st.getItem();
            int ammo = GunItem.getAmmo(st, g.type);
            int slot = p.getInventory().selected;
            if (slot != lastSlot || g != lastGun) {
                lastSlot = slot;
                lastGun = g;
                lastAmmo = ammo;
            } else {
                if (ammo < lastAmmo) {
                    recoilAnim = 1.0f;
                    float k = g.type.recoil * (aiming ? 0.6f : 1.0f);
                    p.setXRot(p.getXRot() - k);
                    p.setYRot(p.getYRot() + (float) ((Math.random() - 0.5) * k * 0.7));
                }
                lastAmmo = ammo;
            }
        } else {
            lastGun = null;
        }
    }

    @SubscribeEvent
    public static void onFov(ComputeFovModifierEvent e) {
        ItemStack held = e.getPlayer().getMainHandItem();
        if (aiming && held.getItem() instanceof GunItem g) {
            float z = g.type.zoom;
            int sc = GunItem.getScope(held);
            if (sc == 1) z *= 0.8f;
            else if (sc == 2 && !g.type.scoped) z *= 0.45f;
            e.setNewFovModifier(e.getNewFovModifier() * z);
        }
    }

    /** First-person gun animation: aim, sprint pose, recoil. */
    @SubscribeEvent
    public static void onRenderHand(RenderHandEvent e) {
        if (e.getHand() != InteractionHand.MAIN_HAND) return;
        if (!(e.getItemStack().getItem() instanceof GunItem g)) return;
        LocalPlayer p = Minecraft.getInstance().player;
        if (p == null) return;
        float pt = e.getPartialTick();
        float ap = Mth.lerp(pt, aimProgO, aimProg);
        if (scopeOverlay(e.getItemStack(), g) && ap > 0.9f) {
            e.setCanceled(true);
            return;
        }
        float sp = Mth.lerp(pt, sprintProgO, sprintProg);
        float ra = Mth.lerp(pt, recoilAnimO, recoilAnim);
        PoseStack ps = e.getPoseStack();
        ps.translate(-0.40f * ap, 0.12f * ap, 0f);
        ps.translate(0.56f, -0.52f, -0.72f);
        float bob = (float) Math.sin((p.tickCount + pt) * 0.7f) * 2.0f * sp;
        ps.mulPose(Axis.XP.rotationDegrees(-28f * sp + 7f * ra + bob));
        ps.mulPose(Axis.YP.rotationDegrees(28f * sp));
        ps.translate(0f, -0.18f * sp, 0.12f * ra);
        ps.translate(-0.56f, 0.52f, 0.72f);
    }

    /** Sniper scope overlay (drawn under the hotbar). */
    @SubscribeEvent
    public static void onGuiLayer(RenderGuiLayerEvent.Pre e) {
        if (!e.getName().equals(VanillaGuiLayers.CROSSHAIR)) return;
        Minecraft mc = Minecraft.getInstance();
        LocalPlayer p = mc.player;
        if (p == null || !(p.getMainHandItem().getItem() instanceof GunItem g)) return;
        if (!scopeOverlay(p.getMainHandItem(), g) || aimProg < 0.9f) return;
        GuiGraphics gg = e.getGuiGraphics();
        int w = gg.guiWidth();
        int h = gg.guiHeight();
        int cx = w / 2;
        int cy = h / 2;
        int r = (int) (h * 0.42f);
        for (int y = 0; y < h; y++) {
            int dy = y - cy;
            if (Math.abs(dy) >= r) {
                gg.fill(0, y, w, y + 1, 0xFF000000);
            } else {
                int hw = (int) Math.sqrt((double) r * r - (double) dy * dy);
                gg.fill(0, y, cx - hw, y + 1, 0xFF000000);
                gg.fill(cx + hw, y, w, y + 1, 0xFF000000);
            }
        }
        gg.fill(cx - r, cy, cx + r, cy + 1, 0xCC000000);
        gg.fill(cx, cy - r, cx + 1, cy + r, 0xCC000000);
    }

    /** Ammo counter HUD (bottom right). */
    @SubscribeEvent
    public static void onHud(RenderGuiEvent.Post e) {
        Minecraft mc = Minecraft.getInstance();
        LocalPlayer p = mc.player;
        if (p == null || mc.options.hideGui) return;
        ItemStack st = p.getMainHandItem();
        if (!(st.getItem() instanceof GunItem g)) return;
        GuiGraphics gg = e.getGuiGraphics();
        Font font = mc.font;
        int w = gg.guiWidth();
        int h = gg.guiHeight();
        int ammo = GunItem.getAmmo(st, g.type);
        boolean reloading = GunItem.getReload(st) > 0;
        String reserve = p.getAbilities().instabuild ? "inf" : String.valueOf(GunItem.countAmmo(p));
        String main = reloading ? "RELOADING..." : ammo + " / " + g.type.magSize;
        int color = reloading ? 0xFFAAAAAA : (ammo <= Math.max(1, g.type.magSize / 5) ? 0xFFFF5555 : 0xFFFFD700);
        int x = w - 14;
        int y = h - 54;
        gg.drawString(font, st.getHoverName(), x - font.width(st.getHoverName()), y - 12, 0xFFFFFFFF, true);
        gg.drawString(font, main, x - font.width(main), y, color, true);
        String res = "Reserve: " + reserve;
        gg.drawString(font, res, x - font.width(res), y + 11, 0xFFAAAAAA, true);
    }
}
